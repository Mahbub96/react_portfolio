"use strict";(()=>{var e={};e.id=436,e.ids=[436],e.modules={11185:e=>{e.exports=require("mongoose")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},16679:(e,a,i)=>{i.r(a),i.d(a,{originalPathname:()=>$,patchFetch:()=>w,requestAsyncStorage:()=>u,routeModule:()=>d,serverHooks:()=>y,staticGenerationAsyncStorage:()=>f});var o={};i.r(o),i.d(o,{GET:()=>c,dynamic:()=>s});var t=i(49303),l=i(88716),n=i(60670),g=i(87070),r=i(52498),m=i(53569);let s="force-dynamic";async function c(e){try{let{searchParams:a}=new URL(e.url),i=a.get("type");if("images"===i)return h();return p()}catch(e){return console.error("Error generating sitemap:",e),new g.NextResponse("Error generating sitemap",{status:500})}}async function p(){let e="https://mahbub.dev";try{let a=await (0,r.Z)(),i=[];a&&(i=await m.Z.find({}).lean());let o=i.find(e=>"Projects"===e.collectionName)?.data||[],t=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
    <loc>${e}</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
    <image:image>
      <image:loc>${e}/assets/img/profile.png</image:loc>
      <image:title>Mahbub Alam - Full Stack Developer Professional Headshot</image:title>
      <image:caption>Professional headshot of Mahbub Alam, Full Stack Developer based in Dhaka, Bangladesh</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/profile-image</image:license>
    </image:image>
    <image:image>
      <image:loc>${e}/assets/img/profile-og.png</image:loc>
      <image:title>Mahbub Alam Portfolio Open Graph Image</image:title>
      <image:caption>Mahbub Alam Portfolio Banner for Social Media</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/profile-image</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/contact</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.9</priority>
  </url>
  
  <url>
    <loc>${e}/projects</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>
  
  <url>
    <loc>${e}/skills</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  
  <url>
    <loc>${e}/#about</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  
  <url>
    <loc>${e}/#experience</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  
  <url>
    <loc>${e}/#education</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  
  <url>
    <loc>${e}/#contact</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  
  ${o.map((a,i)=>`
  <url>
    <loc>${e}/#projects</loc>
    <lastmod>${new Date(a.updatedAt||a.createdAt||Date.now()).toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
    ${a.src?`
    <image:image>
      <image:loc>${a.src.startsWith("http")?a.src:`${e}${a.src}`}</image:loc>
      <image:title>${a.name} - Project Screenshot</image:title>
      <image:caption>${a.desc||`Screenshot of ${a.name} project`}</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/project-images</image:license>
    </image:image>
    `:""}
  </url>
  `).join("")}
</urlset>`;return new g.NextResponse(t,{headers:{"Content-Type":"application/xml","Cache-Control":"public, max-age=86400"}})}catch(i){console.error("Error generating main sitemap:",i);let a=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
    <loc>${e}</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
    <image:image>
      <image:loc>${e}/assets/img/profile.png</image:loc>
      <image:title>Mahbub Alam - Full Stack Developer Professional Headshot</image:title>
      <image:caption>Professional headshot of Mahbub Alam, Full Stack Developer</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/profile-image</image:license>
    </image:image>
  </url>
</urlset>`;return new g.NextResponse(a,{headers:{"Content-Type":"application/xml","Cache-Control":"public, max-age=86400"}})}}async function h(){let e="https://mahbub.dev",a=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  
  <!-- Profile Images -->
  <url>
    <loc>${e}/assets/img/profile.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
    <image:image>
      <image:loc>${e}/assets/img/profile.png</image:loc>
      <image:title>Mahbub Alam - Full Stack Developer Professional Headshot</image:title>
      <image:caption>Professional headshot of Mahbub Alam, Full Stack Developer based in Dhaka, Bangladesh. High-quality professional portrait for portfolio and business use.</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/profile-image</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/profile-og.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
    <image:image>
      <image:loc>${e}/assets/img/profile-og.png</image:loc>
      <image:title>Mahbub Alam Portfolio Open Graph Image</image:title>
      <image:caption>Mahbub Alam Portfolio Banner optimized for social media sharing and Open Graph protocol</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/profile-image</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/profile-twitter.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
    <image:image>
      <image:loc>${e}/assets/img/profile-twitter.png</image:loc>
      <image:title>Mahbub Alam Portfolio Twitter Card</image:title>
      <image:caption>Mahbub Alam Portfolio optimized for Twitter sharing and Twitter Cards</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/profile-image</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/profile-thumbnail.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
    <image:image>
      <image:loc>${e}/assets/img/profile-thumbnail.png</image:loc>
      <image:title>Mahbub Alam Profile Thumbnail</image:title>
      <image:caption>Thumbnail version of Mahbub Alam's professional headshot for use in lists and previews</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/profile-image</image:license>
    </image:image>
  </url>
  
  <!-- Technology Icons -->
  <url>
    <loc>${e}/assets/img/tech/react.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
    <image:image>
      <image:loc>${e}/assets/img/tech/react.png</image:loc>
      <image:title>React.js Technology Icon</image:title>
      <image:caption>React.js logo and technology icon representing React development skills</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/tech-icons</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/tech/nodejs.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
    <image:image>
      <image:loc>${e}/assets/img/tech/nodejs.png</image:loc>
      <image:title>Node.js Technology Icon</image:title>
      <image:caption>Node.js logo and technology icon representing Node.js development skills</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/tech-icons</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/tech/php.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
    <image:image>
      <image:loc>${e}/assets/img/tech/php.png</image:loc>
      <image:title>PHP Technology Icon</image:title>
      <image:caption>PHP logo and technology icon representing PHP development skills</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/tech-icons</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/tech/laravel.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
    <image:image>
      <image:loc>${e}/assets/img/tech/laravel.png</image:loc>
      <image:title>Laravel Technology Icon</image:title>
      <image:caption>Laravel logo and technology icon representing Laravel framework skills</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/tech-icons</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/tech/mongodb.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
    <image:image>
      <image:loc>${e}/assets/img/tech/mongodb.png</image:loc>
      <image:title>MongoDB Technology Icon</image:title>
      <image:caption>MongoDB logo and technology icon representing MongoDB database skills</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/tech-icons</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/tech/aws.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
    <image:image>
      <image:loc>${e}/assets/img/tech/aws.png</image:loc>
      <image:title>AWS Technology Icon</image:title>
      <image:caption>AWS logo and technology icon representing Amazon Web Services cloud skills</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/tech-icons</image:license>
    </image:image>
  </url>
  
  <url>
    <loc>${e}/assets/img/tech/docker.png</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
    <image:image>
      <image:loc>${e}/assets/img/tech/docker.png</image:loc>
      <image:title>Docker Technology Icon</image:title>
      <image:caption>Docker logo and technology icon representing Docker containerization skills</image:caption>
      <image:geo_location>Dhaka, Bangladesh</image:geo_location>
      <image:license>${e}/licenses/tech-icons</image:license>
    </image:image>
  </url>
</urlset>`;return new g.NextResponse(a,{headers:{"Content-Type":"application/xml","Cache-Control":"public, max-age=86400"}})}let d=new t.AppRouteRouteModule({definition:{kind:l.x.APP_ROUTE,page:"/api/sitemap/route",pathname:"/api/sitemap",filename:"route",bundlePath:"app/api/sitemap/route"},resolvedPagePath:"/Users/mahbub/Desktop/Others/Home Task/react_portfolio/src/app/api/sitemap/route.js",nextConfigOutput:"standalone",userland:o}),{requestAsyncStorage:u,staticGenerationAsyncStorage:f,serverHooks:y}=d,$="/api/sitemap/route";function w(){return(0,n.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:f})}},52498:(e,a,i)=>{i.d(a,{Z:()=>g});var o=i(11185),t=i.n(o);let l=process.env.MONGODB_URI||null;l||console.warn("MONGODB_URI is not defined — database connections will be skipped.");let n=global.mongoose;n||(n=global.mongoose={conn:null,promise:null});let g=async function(){if(!l)return null;if(n.conn)return n.conn;n.promise||(n.promise=t().connect(l,{bufferCommands:!1}).then(e=>e));try{n.conn=await n.promise}catch(e){throw console.error("Failed to connect to MongoDB:",e),n.promise=null,e}return console.log("MongoDB connected successfully"),n.conn}},53569:(e,a,i)=>{i.d(a,{Z:()=>n});var o=i(11185),t=i.n(o);let l=new(t()).Schema({collectionName:{type:String,required:!0,enum:["profile","Skills","Experiences","Projects","Educations","Banner","About","Contact"]},data:{type:t().Schema.Types.Mixed,default:[]},lastUpdate:{type:Date,default:Date.now}},{timestamps:!0});l.index({collectionName:1},{unique:!0});let n=t().models.PortfolioData||t().model("PortfolioData",l)}};var a=require("../../../webpack-runtime.js");a.C(e);var i=e=>a(a.s=e),o=a.X(0,[948,972],()=>i(16679));module.exports=o})();