# Production Deployment Instructions

## Prerequisites
- Node.js (v18 or higher recommended)
- Yarn or npm package manager
- PM2 (for process management) - Install with: npm install -g pm2

## Setup Steps

1. **Extract the zip file**
   ```bash
   unzip mahbub-portfolio-production-20251102-004651.zip
   cd mahbub-portfolio-production-*/
   ```

2. **Configure environment variables**
   ```bash
   cp .env .env.backup || true  # Backup if exists
   cp .env.example .env 2>/dev/null || true
   # Edit .env with your production values (MONGODB_URI, etc.)
   ```
   **Important:** Make sure `.env` file exists and contains `MONGODB_URI` before running the seeder.

3. **Install ALL dependencies (required for seeder and build)**
   ```bash
   yarn install --frozen-lockfile --production=false
   ```
   or
   ```bash
   npm ci --production=false
   ```
   **Note:** Do NOT use `--production` flag. The seeder requires dependencies like `dotenv` and `mongoose`.

4. **Run database seeder (recommended for initial setup)**
   ```bash
   node scripts/seedProjects.js
   ```
   or
   ```bash
   yarn seed
   ```
   Note: The seeder file is included in the zip package at `scripts/seedProjects.js`
   **Make sure dependencies are installed before running the seeder.**

5. **Start the application**

   **Option A: Using PM2 (Recommended)**
   ```bash
   pm2 start ecosystem.config.js
   pm2 save
   ```

   **Option B: Using npm/yarn**
   ```bash
   yarn start
   ```
   or
   ```bash
   npm start
   ```

6. **Verify deployment**
   - Check if the application is running on the configured port
   - Monitor logs: `pm2 logs` or check console output

## File Structure
- `.next/` - Next.js build output
- `public/` - Static assets
- `scripts/` - Utility scripts (seeders, etc.)
- `package.json` - Project dependencies
- `ecosystem.config.js` - PM2 configuration

## Notes
- The standalone build includes all necessary server files
- Static assets are in `.next/static/`
- Public assets are in `public/`
- Environment variables must be configured in `.env`

## Troubleshooting
- Ensure all environment variables are set correctly
- Check Node.js version compatibility
- Verify MongoDB connection (if applicable)
- Review PM2 logs for errors: `pm2 logs`
